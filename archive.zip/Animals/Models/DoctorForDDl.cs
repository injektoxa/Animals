﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Animals.Models
{
    public class DoctorForDDl
    {
        public string Name { set; get; }
        public Guid Id { set; get; }
    }
}